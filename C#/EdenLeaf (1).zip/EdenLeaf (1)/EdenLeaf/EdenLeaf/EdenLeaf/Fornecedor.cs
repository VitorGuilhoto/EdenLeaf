﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdenLeaf
{
    internal class Fornecedor
    {
        private int cnpj;
        private int telefone;
        private string nome;
        private string endereco;
        private int id;

        //ID ---------------------------------------------------------------------
        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }


        //CNPJ -------------------------------------------------------------------
        public int getCnpj()
        {
            return cnpj;
        }
        public void setCnpj(int cnpj)
        {
            this.cnpj = cnpj;
        }

        //TELEFONE --------------------------------------------------------------
        public int getTelefone()
        {
            return telefone;
        }

        public void setTelefone(int telefone)
        {
            this.telefone = telefone;
        }

        //ENDEREÇO ----------------------------------------------------------------
        public string getEndereco()
        {
            return endereco;
        }

        public void setEndereco(string endereco)
        {
            this.endereco = endereco;
        }

        //NOME ---------------------------------------------------------------
        public string getNome()
        {
            return nome;
        }

        public void setNome(string nome)
        {
            this.nome = nome;
        }
    }
}
