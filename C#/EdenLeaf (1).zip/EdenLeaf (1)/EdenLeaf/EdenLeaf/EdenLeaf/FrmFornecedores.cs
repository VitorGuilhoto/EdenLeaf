﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;


namespace EdenLeaf
{
    public partial class FrmFornecedor : Form
    {
        NpgsqlConnection conexao;
        private ComboBox CblTelefone;
        private Label LblTelefone;
        private ComboBox CblCnpj;
        private Label LblCnpj;
        private ComboBox CblEndereco;
        private Label LblEndereco;
        private Label LblFornecedores;
        private ComboBox CblNome;
        private Button BtnCancelar;
        private Button BtnExcluir;
        private Button BtnEditar;
        private Button BtnNovo;
        private Label LblNome;
        private Label LblBusca;
        private TextBox TxtBusca;
        private DataGridView DtgFornecedor;
        private Button BtnBusca;
        int IdFornecedor;

        public FrmFornecedor()
        {
            InitializeComponent();

            conexao = new NpgsqlConnection(connectionString:
               "Server=pgsql.projetoscti.com.br; " +
                "Port=5432; " +
                "User ID= projetoscti20; " +
                "Password=720689; " +
                "Database= projetoscti20; " +
                "Pooling=true;"
            );

            CarregaDados(null);
        }

        private void CarregaDados(string comando)
        {
            string query = comando != null
                           ? comando
                           : "SELECT fr.id_fornecedor, fr.nome_fornecedor," +
                           "fr.cnpj_fornecedor," +
                           "fr.endereco_fornecedor," +
                           "fr.telefone_fornecedor " +
                           "FROM tbl_fornecedor AS fr;";

            try
            {
                conexao.Open();

                using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(query, conexao))
                {
                    using (DataTable dt = new DataTable())
                    {
                        da.Fill(dt);
                        DtgFornecedor.DataSource = dt;
                    }
                }

                conexao.Close();
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }


        }




        private void LimpaCampos()
        {
            CblNome.ResetText();
            CblCnpj.ResetText();
            CblEndereco.ResetText();
            CblTelefone.ResetText();

        }

        private void Reset()
        {
            BtnEditar.Visible = false;
            BtnExcluir.Visible = false;
            BtnCancelar.Visible = false;
            BtnNovo.Visible = true;

        }




        private void DtgFornecedor_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            this.IdFornecedor = (int)DtgFornecedor.SelectedRows[0].Cells[0].Value;
            var nomeFornecedor = DtgFornecedor.SelectedRows[0].Cells[1].Value;
            var cnpjFornecedor = DtgFornecedor.SelectedRows[0].Cells[2].Value;
            var enderecoFornecedor = DtgFornecedor.SelectedRows[0].Cells[3].Value;
            var telefoneFornecedor = DtgFornecedor.SelectedRows[0].Cells[4].Value;

            CblNome.Text = nomeFornecedor.ToString();
            CblCnpj.Text = cnpjFornecedor.ToString();
            CblEndereco.Text = enderecoFornecedor.ToString();
            CblTelefone.Text = telefoneFornecedor.ToString();

            BtnEditar.Visible = true;
            BtnExcluir.Visible = true;
            BtnCancelar.Visible = true;
            BtnNovo.Visible = false;
        }


        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFornecedor));
            this.CblTelefone = new System.Windows.Forms.ComboBox();
            this.LblTelefone = new System.Windows.Forms.Label();
            this.CblCnpj = new System.Windows.Forms.ComboBox();
            this.LblCnpj = new System.Windows.Forms.Label();
            this.CblEndereco = new System.Windows.Forms.ComboBox();
            this.LblEndereco = new System.Windows.Forms.Label();
            this.LblFornecedores = new System.Windows.Forms.Label();
            this.CblNome = new System.Windows.Forms.ComboBox();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnNovo = new System.Windows.Forms.Button();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.DtgFornecedor = new System.Windows.Forms.DataGridView();
            this.BtnBusca = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DtgFornecedor)).BeginInit();
            this.SuspendLayout();
            // 
            // CblTelefone
            // 
            this.CblTelefone.FormattingEnabled = true;
            this.CblTelefone.Location = new System.Drawing.Point(48, 209);
            this.CblTelefone.Name = "CblTelefone";
            this.CblTelefone.Size = new System.Drawing.Size(246, 28);
            this.CblTelefone.TabIndex = 81;
            // 
            // LblTelefone
            // 
            this.LblTelefone.AutoSize = true;
            this.LblTelefone.BackColor = System.Drawing.Color.ForestGreen;
            this.LblTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTelefone.ForeColor = System.Drawing.SystemColors.Control;
            this.LblTelefone.Location = new System.Drawing.Point(48, 181);
            this.LblTelefone.Name = "LblTelefone";
            this.LblTelefone.Size = new System.Drawing.Size(95, 25);
            this.LblTelefone.TabIndex = 80;
            this.LblTelefone.Text = "Telefone:";
            // 
            // CblCnpj
            // 
            this.CblCnpj.FormattingEnabled = true;
            this.CblCnpj.Location = new System.Drawing.Point(395, 98);
            this.CblCnpj.Name = "CblCnpj";
            this.CblCnpj.Size = new System.Drawing.Size(222, 28);
            this.CblCnpj.TabIndex = 79;
            // 
            // LblCnpj
            // 
            this.LblCnpj.AutoSize = true;
            this.LblCnpj.BackColor = System.Drawing.Color.ForestGreen;
            this.LblCnpj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCnpj.ForeColor = System.Drawing.SystemColors.Control;
            this.LblCnpj.Location = new System.Drawing.Point(401, 70);
            this.LblCnpj.Name = "LblCnpj";
            this.LblCnpj.Size = new System.Drawing.Size(71, 25);
            this.LblCnpj.TabIndex = 78;
            this.LblCnpj.Text = "CNPJ:";
            // 
            // CblEndereco
            // 
            this.CblEndereco.FormattingEnabled = true;
            this.CblEndereco.Location = new System.Drawing.Point(344, 209);
            this.CblEndereco.Name = "CblEndereco";
            this.CblEndereco.Size = new System.Drawing.Size(273, 28);
            this.CblEndereco.TabIndex = 77;
            // 
            // LblEndereco
            // 
            this.LblEndereco.AutoSize = true;
            this.LblEndereco.BackColor = System.Drawing.Color.ForestGreen;
            this.LblEndereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEndereco.ForeColor = System.Drawing.SystemColors.Control;
            this.LblEndereco.Location = new System.Drawing.Point(352, 181);
            this.LblEndereco.Name = "LblEndereco";
            this.LblEndereco.Size = new System.Drawing.Size(96, 25);
            this.LblEndereco.TabIndex = 76;
            this.LblEndereco.Text = "Endereço";
            // 
            // LblFornecedores
            // 
            this.LblFornecedores.AutoSize = true;
            this.LblFornecedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFornecedores.ForeColor = System.Drawing.Color.DarkGreen;
            this.LblFornecedores.Location = new System.Drawing.Point(200, 14);
            this.LblFornecedores.Name = "LblFornecedores";
            this.LblFornecedores.Size = new System.Drawing.Size(232, 47);
            this.LblFornecedores.TabIndex = 75;
            this.LblFornecedores.Text = "Fornecedor";
            // 
            // CblNome
            // 
            this.CblNome.FormattingEnabled = true;
            this.CblNome.Location = new System.Drawing.Point(43, 98);
            this.CblNome.Name = "CblNome";
            this.CblNome.Size = new System.Drawing.Size(307, 28);
            this.CblNome.TabIndex = 74;
            this.CblNome.SelectedIndexChanged += new System.EventHandler(this.CblNome_SelectedIndexChanged);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.Color.Orange;
            this.BtnCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Underline);
            this.BtnCancelar.Location = new System.Drawing.Point(497, 271);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(120, 46);
            this.BtnCancelar.TabIndex = 73;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Visible = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click_1);
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.BackColor = System.Drawing.Color.LightCoral;
            this.BtnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Underline);
            this.BtnExcluir.Location = new System.Drawing.Point(372, 271);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(100, 46);
            this.BtnExcluir.TabIndex = 72;
            this.BtnExcluir.Text = "Excluir";
            this.BtnExcluir.UseVisualStyleBackColor = false;
            this.BtnExcluir.Visible = false;
            this.BtnExcluir.Click += new System.EventHandler(this.BtnExcluir_Click_1);
            // 
            // BtnEditar
            // 
            this.BtnEditar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.BtnEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Underline);
            this.BtnEditar.Location = new System.Drawing.Point(254, 271);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(91, 46);
            this.BtnEditar.TabIndex = 71;
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.UseVisualStyleBackColor = false;
            this.BtnEditar.Visible = false;
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click_1);
            // 
            // BtnNovo
            // 
            this.BtnNovo.BackColor = System.Drawing.Color.YellowGreen;
            this.BtnNovo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Underline);
            this.BtnNovo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnNovo.Location = new System.Drawing.Point(37, 271);
            this.BtnNovo.Name = "BtnNovo";
            this.BtnNovo.Size = new System.Drawing.Size(190, 46);
            this.BtnNovo.TabIndex = 70;
            this.BtnNovo.Text = "Novo Fornecedor";
            this.BtnNovo.UseVisualStyleBackColor = false;
            this.BtnNovo.Click += new System.EventHandler(this.BtnNovo_Click_1);
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.BackColor = System.Drawing.Color.ForestGreen;
            this.LblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNome.ForeColor = System.Drawing.SystemColors.Control;
            this.LblNome.Location = new System.Drawing.Point(43, 70);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(195, 25);
            this.LblNome.TabIndex = 69;
            this.LblNome.Text = "Nome do fornecedor:";
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.LblBusca.Location = new System.Drawing.Point(41, 349);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(203, 25);
            this.LblBusca.TabIndex = 68;
            this.LblBusca.Text = "Pesquisar por NOME:";
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(185, 348);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(201, 26);
            this.TxtBusca.TabIndex = 67;
            // 
            // DtgFornecedor
            // 
            this.DtgFornecedor.BackgroundColor = System.Drawing.Color.DarkSeaGreen;
            this.DtgFornecedor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgFornecedor.Location = new System.Drawing.Point(43, 375);
            this.DtgFornecedor.MultiSelect = false;
            this.DtgFornecedor.Name = "DtgFornecedor";
            this.DtgFornecedor.RowHeadersWidth = 62;
            this.DtgFornecedor.Size = new System.Drawing.Size(578, 131);
            this.DtgFornecedor.TabIndex = 66;
            this.DtgFornecedor.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DtgFornecedor_RowHeaderMouseClick);
            // 
            // BtnBusca
            // 
            this.BtnBusca.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnBusca.BackgroundImage")));
            this.BtnBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnBusca.Location = new System.Drawing.Point(392, 343);
            this.BtnBusca.Name = "BtnBusca";
            this.BtnBusca.Size = new System.Drawing.Size(28, 26);
            this.BtnBusca.TabIndex = 82;
            this.BtnBusca.UseVisualStyleBackColor = true;
            this.BtnBusca.Click += new System.EventHandler(this.BtnBusca_Click_1);
            // 
            // FrmFornecedor
            // 
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(670, 539);
            this.Controls.Add(this.BtnBusca);
            this.Controls.Add(this.CblTelefone);
            this.Controls.Add(this.LblTelefone);
            this.Controls.Add(this.CblCnpj);
            this.Controls.Add(this.LblCnpj);
            this.Controls.Add(this.CblEndereco);
            this.Controls.Add(this.LblEndereco);
            this.Controls.Add(this.LblFornecedores);
            this.Controls.Add(this.CblNome);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnExcluir);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnNovo);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgFornecedor);
            this.MaximizeBox = false;
            this.Name = "FrmFornecedor";
            ((System.ComponentModel.ISupportInitialize)(this.DtgFornecedor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void CblNome_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var query = $"SELECT id_fornecedor FROM tbl_fornecedor WHERE nome_fornecedor = '{CblNome.Text}';";
                dynamic resultado = conexao.Query<Fornecedor>(sql: query);

                this.IdFornecedor = resultado[0].Id;

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }

        private void BtnNovo_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(CblNome.Text) &&
                !string.IsNullOrEmpty(CblCnpj.Text) &&
                !string.IsNullOrEmpty(CblEndereco.Text) &&
                !string.IsNullOrEmpty(CblTelefone.Text))
            {


                try
                {
                    var query = "INSERT INTO tbl_fornecedor (nome_fornecedor,cnpj_fornecedor," +
                        "endereco_fornecedor, " +
                        "telefone_fornecedor) VALUES " +
                        $"('{CblNome.Text}'," +
                        $"'{CblCnpj.Text}','{CblEndereco.Text}','{CblTelefone.Text}')";


                    conexao.Query(sql: query);
                    MessageBox.Show("Novo fornecedor cadastrado com sucesso!");
                    LimpaCampos();
                    CarregaDados(null);



                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Campos obrigatórios não preenchidos!");
            }
        }

        private void BtnEditar_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(CblNome.Text) &&
                    !string.IsNullOrEmpty(CblCnpj.Text) &&
                    !string.IsNullOrEmpty(CblEndereco.Text) &&
                    !string.IsNullOrEmpty(CblTelefone.Text))
            {
                try
                {
                    var update = $"UPDATE tbl_fornecedor SET nome_fornecedor ='{CblNome.Text}'," +
                        $"cnpj_fornecedor = '{CblCnpj.Text}'," +
                        $"endereco_fornecedor = '{CblEndereco.Text}'," +
                        $"telefone_fornecedor = '{CblTelefone.Text}' " +
                        $"WHERE id_fornecedor='{IdFornecedor}';";

                    conexao.Query(sql: update);

                    MessageBox.Show("Fonecedor atualizado com sucesso!");
                    LimpaCampos();
                    Reset();
                    CarregaDados(null);

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Campos obrigatórios não preenchidos!");
            }
        }

        private void BtnExcluir_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Deseja excluir este fornecedor?",
                                                  "Atenção!",
                                                  MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                try
                {

                    var delete = $"DELETE FROM tbl_fornecedor " +
                        $"WHERE id_fornecedor='{IdFornecedor}';";

                    conexao.Query(sql: delete);

                    MessageBox.Show("Fornecedor excluído com sucesso!");
                    LimpaCampos();
                    Reset();
                    CarregaDados(null);

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
            else
            {
                LimpaCampos();
                Reset();
                CarregaDados(null);
            }
        }

        private void BtnCancelar_Click_1(object sender, EventArgs e)
        {
            LimpaCampos();
            Reset();
            CarregaDados(null);
        }

        private void BtnBusca_Click_1(object sender, EventArgs e)
        {
            string query = "SELECT id_fornecedor, nome_fornecedor," +
                          "cnpj_fornecedor," +
                          "endereco_fornecedor," +
                          "telefone_fornecedor " +
               "FROM tbl_fornecedor " +
               $"WHERE nome_fornecedor LIKE '%{TxtBusca.Text}%';";
            CarregaDados(query);
        }
    }

}

