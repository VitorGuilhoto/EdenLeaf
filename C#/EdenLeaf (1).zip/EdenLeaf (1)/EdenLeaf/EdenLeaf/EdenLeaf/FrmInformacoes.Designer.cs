﻿namespace EdenLeaf
{
    partial class FrmInformacoes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInformacoes));
            this.LblTitulo1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LblTexto1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.LblTitulo2 = new System.Windows.Forms.Label();
            this.PbCti = new System.Windows.Forms.PictureBox();
            this.LblTexto2 = new System.Windows.Forms.Label();
            this.LblTexto3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PbCti)).BeginInit();
            this.SuspendLayout();
            // 
            // LblTitulo1
            // 
            this.LblTitulo1.AutoSize = true;
            this.LblTitulo1.BackColor = System.Drawing.Color.Transparent;
            this.LblTitulo1.Font = new System.Drawing.Font("Segoe Script", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTitulo1.ForeColor = System.Drawing.Color.DarkGreen;
            this.LblTitulo1.Location = new System.Drawing.Point(39, 82);
            this.LblTitulo1.Name = "LblTitulo1";
            this.LblTitulo1.Size = new System.Drawing.Size(220, 50);
            this.LblTitulo1.TabIndex = 0;
            this.LblTitulo1.Text = "Quem somos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Underline);
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(472, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 46);
            this.label4.TabIndex = 3;
            this.label4.Text = "Informações";
            // 
            // LblTexto1
            // 
            this.LblTexto1.AutoSize = true;
            this.LblTexto1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.LblTexto1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblTexto1.Location = new System.Drawing.Point(12, 132);
            this.LblTexto1.Name = "LblTexto1";
            this.LblTexto1.Size = new System.Drawing.Size(1065, 44);
            this.LblTexto1.TabIndex = 7;
            this.LblTexto1.Text = resources.GetString("LblTexto1.Text");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe Script", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkGreen;
            this.label8.Location = new System.Drawing.Point(44, 488);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(432, 50);
            this.label8.TabIndex = 9;
            this.label8.Text = "Nossos comprometimentos";
            // 
            // LblTitulo2
            // 
            this.LblTitulo2.AutoSize = true;
            this.LblTitulo2.BackColor = System.Drawing.Color.Transparent;
            this.LblTitulo2.Font = new System.Drawing.Font("Segoe Script", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTitulo2.ForeColor = System.Drawing.Color.DarkGreen;
            this.LblTitulo2.Location = new System.Drawing.Point(634, 267);
            this.LblTitulo2.Name = "LblTitulo2";
            this.LblTitulo2.Size = new System.Drawing.Size(360, 50);
            this.LblTitulo2.TabIndex = 10;
            this.LblTitulo2.Text = "Sobre nossos produtos";
            // 
            // PbCti
            // 
            this.PbCti.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PbCti.BackgroundImage")));
            this.PbCti.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbCti.Location = new System.Drawing.Point(48, 218);
            this.PbCti.Name = "PbCti";
            this.PbCti.Size = new System.Drawing.Size(452, 245);
            this.PbCti.TabIndex = 11;
            this.PbCti.TabStop = false;
            // 
            // LblTexto2
            // 
            this.LblTexto2.AutoSize = true;
            this.LblTexto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.LblTexto2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblTexto2.Location = new System.Drawing.Point(548, 328);
            this.LblTexto2.Name = "LblTexto2";
            this.LblTexto2.Size = new System.Drawing.Size(497, 110);
            this.LblTexto2.TabIndex = 12;
            this.LblTexto2.Text = resources.GetString("LblTexto2.Text");
            // 
            // LblTexto3
            // 
            this.LblTexto3.AutoSize = true;
            this.LblTexto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.LblTexto3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblTexto3.Location = new System.Drawing.Point(3, 516);
            this.LblTexto3.Name = "LblTexto3";
            this.LblTexto3.Size = new System.Drawing.Size(1074, 88);
            this.LblTexto3.TabIndex = 14;
            this.LblTexto3.Text = resources.GetString("LblTexto3.Text");
            // 
            // FrmInformacoes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(1111, 627);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.LblTexto3);
            this.Controls.Add(this.LblTexto2);
            this.Controls.Add(this.PbCti);
            this.Controls.Add(this.LblTitulo2);
            this.Controls.Add(this.LblTexto1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LblTitulo1);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmInformacoes";
            this.Text = "FrmInformacoes";
            ((System.ComponentModel.ISupportInitialize)(this.PbCti)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitulo1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label LblTexto1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LblTitulo2;
        private System.Windows.Forms.PictureBox PbCti;
        private System.Windows.Forms.Label LblTexto2;
        private System.Windows.Forms.Label LblTexto3;
    }
}