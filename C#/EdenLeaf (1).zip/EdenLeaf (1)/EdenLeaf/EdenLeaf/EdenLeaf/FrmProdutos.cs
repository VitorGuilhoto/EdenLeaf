﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;


namespace EdenLeaf
{
    public partial class FrmProduto : Form
    {
        private ComboBox CblPreco;
        private ComboBox CblTipo;
        private Button BtnCancelar;
        private Button BtnExcluir;
        private Button BtnEditar;
        private Button BtnNovo;
        private Label LblDataAdicao;
        private Label LblDescricao;
        private Label LblPreco;
        private Label LblTipo;
        private DateTimePicker DtAdicao;
        private TextBox TxtDescricao;
        private Button BtnBusca;
        private Label LblBusca;
        private TextBox TxtBusca;
        private DataGridView DtgPlanta;
        private StatusStrip TsRodape;
        private Label LblProdutos;
        private ToolStripStatusLabel TslPrincipal;
        private Label LblFornecedor;

        NpgsqlConnection conexao;

        int IdPlanta;

        public FrmProduto()
        {
            InitializeComponent();

            conexao = new NpgsqlConnection(connectionString:
               "Server=pgsql.projetoscti.com.br; " +
               "Port=5432; " +
               "User ID= projetoscti20; " +
               "Password=720689; " +
               "Database= projetoscti20; " +
               "Pooling=true;"
           );

            CarregaDados(null);
        }

        private void CarregaDados(string comando)
        {


            string query = comando != null
                           ? comando
                           : "SELECT id_planta ," +
                           "tipo_planta," +
                           "preco_planta," +
                           "descricao_planta," +
                           "data_adicao_planta " +
                           "FROM tbl_planta;";


            try
            {
                conexao.Open();

                using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(query, conexao))
                {
                    using (DataTable dt = new DataTable())
                    {
                        da.Fill(dt);
                        DtgPlanta.DataSource = dt;
                    }
                }

                conexao.Close();
                TslPrincipal.Text = "Pronto!";
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
                TslPrincipal.Text = "ERRO: " + ex.Message;
            }


        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProduto));
            this.CblPreco = new System.Windows.Forms.ComboBox();
            this.CblTipo = new System.Windows.Forms.ComboBox();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnNovo = new System.Windows.Forms.Button();
            this.LblDataAdicao = new System.Windows.Forms.Label();
            this.LblDescricao = new System.Windows.Forms.Label();
            this.LblPreco = new System.Windows.Forms.Label();
            this.LblTipo = new System.Windows.Forms.Label();
            this.DtAdicao = new System.Windows.Forms.DateTimePicker();
            this.TxtDescricao = new System.Windows.Forms.TextBox();
            this.BtnBusca = new System.Windows.Forms.Button();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.DtgPlanta = new System.Windows.Forms.DataGridView();
            this.TsRodape = new System.Windows.Forms.StatusStrip();
            this.TslPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.LblProdutos = new System.Windows.Forms.Label();
            this.LblFornecedor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DtgPlanta)).BeginInit();
            this.TsRodape.SuspendLayout();
            this.SuspendLayout();
            // 
            // CblPreco
            // 
            this.CblPreco.FormattingEnabled = true;
            this.CblPreco.Location = new System.Drawing.Point(202, 93);
            this.CblPreco.Name = "CblPreco";
            this.CblPreco.Size = new System.Drawing.Size(74, 28);
            this.CblPreco.TabIndex = 41;
            // 
            // CblTipo
            // 
            this.CblTipo.FormattingEnabled = true;
            this.CblTipo.Location = new System.Drawing.Point(30, 94);
            this.CblTipo.Name = "CblTipo";
            this.CblTipo.Size = new System.Drawing.Size(121, 28);
            this.CblTipo.TabIndex = 40;
            this.CblTipo.SelectedIndexChanged += new System.EventHandler(this.CblTipo_SelectedIndexChanged);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.Color.Orange;
            this.BtnCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline);
            this.BtnCancelar.Location = new System.Drawing.Point(456, 258);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(97, 33);
            this.BtnCancelar.TabIndex = 39;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Visible = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click_1);
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.BackColor = System.Drawing.Color.LightCoral;
            this.BtnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline);
            this.BtnExcluir.Location = new System.Drawing.Point(333, 258);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(97, 33);
            this.BtnExcluir.TabIndex = 38;
            this.BtnExcluir.Text = "Excluir";
            this.BtnExcluir.UseVisualStyleBackColor = false;
            this.BtnExcluir.Visible = false;
            this.BtnExcluir.Click += new System.EventHandler(this.BtnExcluir_Click_1);
            // 
            // BtnEditar
            // 
            this.BtnEditar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.BtnEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEditar.Location = new System.Drawing.Point(208, 258);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(97, 33);
            this.BtnEditar.TabIndex = 37;
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.UseVisualStyleBackColor = false;
            this.BtnEditar.Visible = false;
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click_1);
            // 
            // BtnNovo
            // 
            this.BtnNovo.BackColor = System.Drawing.Color.YellowGreen;
            this.BtnNovo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline);
            this.BtnNovo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnNovo.Location = new System.Drawing.Point(77, 258);
            this.BtnNovo.Name = "BtnNovo";
            this.BtnNovo.Size = new System.Drawing.Size(106, 33);
            this.BtnNovo.TabIndex = 36;
            this.BtnNovo.Text = "Novo Produto";
            this.BtnNovo.UseVisualStyleBackColor = false;
            this.BtnNovo.Click += new System.EventHandler(this.BtnNovo_Click_1);
            // 
            // LblDataAdicao
            // 
            this.LblDataAdicao.AutoSize = true;
            this.LblDataAdicao.BackColor = System.Drawing.Color.ForestGreen;
            this.LblDataAdicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDataAdicao.ForeColor = System.Drawing.SystemColors.Control;
            this.LblDataAdicao.Location = new System.Drawing.Point(346, 75);
            this.LblDataAdicao.Name = "LblDataAdicao";
            this.LblDataAdicao.Size = new System.Drawing.Size(149, 25);
            this.LblDataAdicao.TabIndex = 35;
            this.LblDataAdicao.Text = "Data da adição:";
            // 
            // LblDescricao
            // 
            this.LblDescricao.AutoSize = true;
            this.LblDescricao.BackColor = System.Drawing.Color.ForestGreen;
            this.LblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDescricao.ForeColor = System.Drawing.SystemColors.Control;
            this.LblDescricao.Location = new System.Drawing.Point(27, 149);
            this.LblDescricao.Name = "LblDescricao";
            this.LblDescricao.Size = new System.Drawing.Size(105, 25);
            this.LblDescricao.TabIndex = 34;
            this.LblDescricao.Text = "Descrição:";
            // 
            // LblPreco
            // 
            this.LblPreco.AutoSize = true;
            this.LblPreco.BackColor = System.Drawing.Color.ForestGreen;
            this.LblPreco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPreco.ForeColor = System.Drawing.SystemColors.Control;
            this.LblPreco.Location = new System.Drawing.Point(205, 74);
            this.LblPreco.Name = "LblPreco";
            this.LblPreco.Size = new System.Drawing.Size(69, 25);
            this.LblPreco.TabIndex = 32;
            this.LblPreco.Text = "Preço:";
            // 
            // LblTipo
            // 
            this.LblTipo.AutoSize = true;
            this.LblTipo.BackColor = System.Drawing.Color.ForestGreen;
            this.LblTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTipo.ForeColor = System.Drawing.SystemColors.Control;
            this.LblTipo.Location = new System.Drawing.Point(30, 74);
            this.LblTipo.Name = "LblTipo";
            this.LblTipo.Size = new System.Drawing.Size(142, 25);
            this.LblTipo.TabIndex = 31;
            this.LblTipo.Text = "Tipo da planta:";
            // 
            // DtAdicao
            // 
            this.DtAdicao.Location = new System.Drawing.Point(340, 95);
            this.DtAdicao.Name = "DtAdicao";
            this.DtAdicao.Size = new System.Drawing.Size(235, 26);
            this.DtAdicao.TabIndex = 30;
            // 
            // TxtDescricao
            // 
            this.TxtDescricao.Location = new System.Drawing.Point(28, 168);
            this.TxtDescricao.Multiline = true;
            this.TxtDescricao.Name = "TxtDescricao";
            this.TxtDescricao.Size = new System.Drawing.Size(578, 64);
            this.TxtDescricao.TabIndex = 28;
            // 
            // BtnBusca
            // 
            this.BtnBusca.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnBusca.BackgroundImage")));
            this.BtnBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnBusca.Location = new System.Drawing.Point(355, 324);
            this.BtnBusca.Name = "BtnBusca";
            this.BtnBusca.Size = new System.Drawing.Size(28, 26);
            this.BtnBusca.TabIndex = 27;
            this.BtnBusca.UseVisualStyleBackColor = true;
            this.BtnBusca.Click += new System.EventHandler(this.BtnBusca_Click_1);
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(27, 324);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(150, 20);
            this.LblBusca.TabIndex = 26;
            this.LblBusca.Text = "Pesquisar por TIPO:";
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(130, 324);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(219, 26);
            this.TxtBusca.TabIndex = 25;
            // 
            // DtgPlanta
            // 
            this.DtgPlanta.BackgroundColor = System.Drawing.Color.DarkSeaGreen;
            this.DtgPlanta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgPlanta.Location = new System.Drawing.Point(28, 356);
            this.DtgPlanta.MultiSelect = false;
            this.DtgPlanta.Name = "DtgPlanta";
            this.DtgPlanta.RowHeadersWidth = 62;
            this.DtgPlanta.Size = new System.Drawing.Size(578, 131);
            this.DtgPlanta.TabIndex = 24;
            this.DtgPlanta.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DtgPlanta_RowHeaderMouseClick);
            // 
            // TsRodape
            // 
            this.TsRodape.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.TsRodape.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslPrincipal});
            this.TsRodape.Location = new System.Drawing.Point(0, 509);
            this.TsRodape.Name = "TsRodape";
            this.TsRodape.Size = new System.Drawing.Size(627, 22);
            this.TsRodape.TabIndex = 23;
            this.TsRodape.Text = "statusStrip1";
            // 
            // TslPrincipal
            // 
            this.TslPrincipal.Name = "TslPrincipal";
            this.TslPrincipal.Size = new System.Drawing.Size(0, 15);
            // 
            // LblProdutos
            // 
            this.LblProdutos.AutoSize = true;
            this.LblProdutos.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblProdutos.ForeColor = System.Drawing.Color.DarkGreen;
            this.LblProdutos.Location = new System.Drawing.Point(219, 9);
            this.LblProdutos.Name = "LblProdutos";
            this.LblProdutos.Size = new System.Drawing.Size(164, 47);
            this.LblProdutos.TabIndex = 42;
            this.LblProdutos.Text = "Produto";
            // 
            // LblFornecedor
            // 
            this.LblFornecedor.AutoSize = true;
            this.LblFornecedor.BackColor = System.Drawing.Color.ForestGreen;
            this.LblFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFornecedor.ForeColor = System.Drawing.SystemColors.Control;
            this.LblFornecedor.Location = new System.Drawing.Point(624, 75);
            this.LblFornecedor.Name = "LblFornecedor";
            this.LblFornecedor.Size = new System.Drawing.Size(0, 25);
            this.LblFornecedor.TabIndex = 43;
            // 
            // FrmProduto
            // 
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(627, 531);
            this.Controls.Add(this.LblFornecedor);
            this.Controls.Add(this.LblProdutos);
            this.Controls.Add(this.CblPreco);
            this.Controls.Add(this.CblTipo);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnExcluir);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnNovo);
            this.Controls.Add(this.LblDataAdicao);
            this.Controls.Add(this.LblDescricao);
            this.Controls.Add(this.LblPreco);
            this.Controls.Add(this.LblTipo);
            this.Controls.Add(this.DtAdicao);
            this.Controls.Add(this.TxtDescricao);
            this.Controls.Add(this.BtnBusca);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgPlanta);
            this.Controls.Add(this.TsRodape);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmProduto";
            this.ShowIcon = false;
            ((System.ComponentModel.ISupportInitialize)(this.DtgPlanta)).EndInit();
            this.TsRodape.ResumeLayout(false);
            this.TsRodape.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        private void LimpaCampos()
        {
            CblTipo.ResetText();
            CblPreco.ResetText();

            TxtDescricao.Clear();
            DtAdicao.ResetText();

        }

        private void Reset()
        {
            BtnEditar.Visible = false;
            BtnExcluir.Visible = false;
            BtnCancelar.Visible = false;
            BtnNovo.Visible = true;

            CblTipo.Enabled = true;
        }

        private void CblTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var query = $"SELECT id_planta FROM tbl_planta WHERE tipo_planta = '{CblTipo.Text}';";
                dynamic resultado = conexao.Query<Planta>(sql: query);

                this.IdPlanta = resultado[0].Id;

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
                TslPrincipal.Text = "Erro: " + ex.Message;
            }
        }


        private void BtnNovo_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(CblTipo.Text) &&
               !string.IsNullOrEmpty(CblPreco.Text) &&
               !string.IsNullOrEmpty(TxtDescricao.Text))
            {


                try
                {
                    var day = DtAdicao.Value.Day;
                    var month = DtAdicao.Value.Month;
                    var year = DtAdicao.Value.Year;
                    string dataAdicao = year + "/" + month + "/" + day;

                    var query = "INSERT INTO tbl_planta (tipo_planta," +
                        "preco_planta, " +
                        "descricao_planta, data_adicao_planta) VALUES " +
                        $"('{CblTipo.Text}'," +
                        $"'{CblPreco.Text}','{TxtDescricao.Text}','{dataAdicao}');";


                    conexao.Query(sql: query);
                    MessageBox.Show("Nova adição feita com sucesso!");
                    LimpaCampos();
                    CarregaDados(null);

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                    TslPrincipal.Text = "Erro: " + ex.Message;
                }
            }
            else
            {
                MessageBox.Show("Campos obrigatórios não preenchidos!");
                TslPrincipal.Text = "Campos obrigatórios não preenchidos!";

            }
        }

        private void BtnEditar_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(CblTipo.Text) &&
              !string.IsNullOrEmpty(CblPreco.Text) &&
              !string.IsNullOrEmpty(TxtDescricao.Text))
            {
                try
                {

                    var day = DtAdicao.Value.Day;
                    var month = DtAdicao.Value.Month;
                    var year = DtAdicao.Value.Year;
                    string dataAdicao = year + "/" + month + "/" + day;

                    var update = $"UPDATE tbl_planta SET tipo_planta ='{CblTipo.Text}', preco_planta='{CblPreco.Text}'," +
                        $"data_adicao_planta='{dataAdicao}'," +
                        $"descricao_planta='{TxtDescricao.Text}' " +
                        $"WHERE id_planta='{IdPlanta}';";

                    conexao.Query(sql: update);

                    MessageBox.Show("Planta atualizada com sucesso!!!");
                    LimpaCampos();
                    Reset();
                    CarregaDados(null);

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                    TslPrincipal.Text = "Erro: " + ex.Message;
                }
            }
            else
            {
                MessageBox.Show("Campos obrigatórios não preenchidos!");
                TslPrincipal.Text = "Campos obrigatórios não preenchidos!";

            }
        }

        private void BtnExcluir_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Deseja excluir esta planta?",
                                                  "Atenção!",
                                                  MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                try
                {

                    var delete = $"DELETE FROM tbl_planta " +
                        $"WHERE id_planta='{IdPlanta}';";

                    conexao.Query(sql: delete);

                    MessageBox.Show("Planta excluida com sucesso!!!");
                    LimpaCampos();
                    Reset();
                    CarregaDados(null);

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                    TslPrincipal.Text = "Erro: " + ex.Message;
                }
            }
            else
            {
                LimpaCampos();
                Reset();
                CarregaDados(null);
            }
        }

        private void BtnCancelar_Click_1(object sender, EventArgs e)
        {
            LimpaCampos();
            Reset();
            CarregaDados(null);
        }

        private void BtnBusca_Click_1(object sender, EventArgs e)
        {
            string query = "SELECT id_planta AS Id, tipo_planta AS Tipo, preco_planta AS Preco," +
                "descricao_planta AS Descricao," +
                "data_adicao_planta AS Data_Adicao " +
                "FROM tbl_planta  " +
                $"WHERE tipo_planta LIKE '%{TxtBusca.Text}%';";
            CarregaDados(query);
        }
        private void DtgPlanta_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            this.IdPlanta = (int)DtgPlanta.SelectedRows[0].Cells[0].Value;
            var tipoPlanta = DtgPlanta.SelectedRows[0].Cells[1].Value;
            var precoPlanta = DtgPlanta.SelectedRows[0].Cells[2].Value;
            var descricaoPlanta = DtgPlanta.SelectedRows[0].Cells[3].Value;
            var dataAdicao = DtgPlanta.SelectedRows[0].Cells[4].Value;

            var newDate = dataAdicao.ToString().Split('/');
            int d = int.Parse(newDate[0]);
            int m = int.Parse(newDate[1]);
            int y = int.Parse(newDate[2].Split(' ')[0]);
            DtAdicao.Value = new DateTime(y, m, d);

            CblTipo.Text = tipoPlanta.ToString();
            CblPreco.Text = precoPlanta.ToString();
            TxtDescricao.Text = descricaoPlanta.ToString();

            BtnEditar.Visible = true;
            BtnExcluir.Visible = true;
            BtnCancelar.Visible = true;
            BtnNovo.Visible = false;
        }

    }
}
