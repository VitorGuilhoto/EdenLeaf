﻿namespace EdenLeaf
{
    partial class FrmHome
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHome));
            this.MsHome = new System.Windows.Forms.MenuStrip();
            this.TsmCompra = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmUsuarios = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmFornecedores = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmProdutos = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmInformacoes = new System.Windows.Forms.ToolStripMenuItem();
            this.LblDescricao = new System.Windows.Forms.Label();
            this.LblDescricao2 = new System.Windows.Forms.Label();
            this.PbBanner = new System.Windows.Forms.PictureBox();
            this.PbSculenta = new System.Windows.Forms.PictureBox();
            this.PbCacto = new System.Windows.Forms.PictureBox();
            this.PbVasos = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.MsHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbBanner)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbSculenta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbCacto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbVasos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // MsHome
            // 
            this.MsHome.BackColor = System.Drawing.Color.Green;
            this.MsHome.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.MsHome.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.MsHome.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MsHome.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmCompra,
            this.TsmUsuarios,
            this.TsmFornecedores,
            this.TsmProdutos,
            this.TsmInformacoes});
            this.MsHome.Location = new System.Drawing.Point(0, 0);
            this.MsHome.Name = "MsHome";
            this.MsHome.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MsHome.Size = new System.Drawing.Size(1065, 38);
            this.MsHome.TabIndex = 4;
            this.MsHome.Text = "menuStrip1";
            // 
            // TsmCompra
            // 
            this.TsmCompra.Name = "TsmCompra";
            this.TsmCompra.Size = new System.Drawing.Size(16, 34);
            // 
            // TsmUsuarios
            // 
            this.TsmUsuarios.Name = "TsmUsuarios";
            this.TsmUsuarios.Size = new System.Drawing.Size(16, 34);
            // 
            // TsmFornecedores
            // 
            this.TsmFornecedores.BackColor = System.Drawing.Color.ForestGreen;
            this.TsmFornecedores.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.TsmFornecedores.ForeColor = System.Drawing.SystemColors.Control;
            this.TsmFornecedores.Name = "TsmFornecedores";
            this.TsmFornecedores.Size = new System.Drawing.Size(162, 34);
            this.TsmFornecedores.Text = "Fornecedores";
            this.TsmFornecedores.Click += new System.EventHandler(this.TsmFornecedores_Click);
            // 
            // TsmProdutos
            // 
            this.TsmProdutos.BackColor = System.Drawing.Color.ForestGreen;
            this.TsmProdutos.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.TsmProdutos.ForeColor = System.Drawing.SystemColors.Control;
            this.TsmProdutos.Name = "TsmProdutos";
            this.TsmProdutos.Size = new System.Drawing.Size(116, 34);
            this.TsmProdutos.Text = "Produtos";
            this.TsmProdutos.Click += new System.EventHandler(this.TsmProdutos_Click);
            // 
            // TsmInformacoes
            // 
            this.TsmInformacoes.BackColor = System.Drawing.Color.ForestGreen;
            this.TsmInformacoes.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.TsmInformacoes.ForeColor = System.Drawing.SystemColors.Control;
            this.TsmInformacoes.Name = "TsmInformacoes";
            this.TsmInformacoes.Size = new System.Drawing.Size(149, 34);
            this.TsmInformacoes.Text = "Informações";
            this.TsmInformacoes.Click += new System.EventHandler(this.TsmInformacoes_Click);
            // 
            // LblDescricao
            // 
            this.LblDescricao.AutoSize = true;
            this.LblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.LblDescricao.Location = new System.Drawing.Point(147, 307);
            this.LblDescricao.Name = "LblDescricao";
            this.LblDescricao.Size = new System.Drawing.Size(819, 22);
            this.LblDescricao.TabIndex = 5;
            this.LblDescricao.Text = "Bem-vindo(a) ao Eden Leaf! Descubra a beleza natural em sua forma mais encantador" +
    "a aqui mesmo. ";
            // 
            // LblDescricao2
            // 
            this.LblDescricao2.AutoSize = true;
            this.LblDescricao2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.LblDescricao2.Location = new System.Drawing.Point(115, 333);
            this.LblDescricao2.Name = "LblDescricao2";
            this.LblDescricao2.Size = new System.Drawing.Size(861, 22);
            this.LblDescricao2.TabIndex = 6;
            this.LblDescricao2.Text = "Nossa loja é o paraíso dos amantes de suculentas e cactos, onde a natureza se enc" +
    "ontra com a elegância.";
            // 
            // PbBanner
            // 
            this.PbBanner.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PbBanner.BackgroundImage")));
            this.PbBanner.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbBanner.Location = new System.Drawing.Point(278, 68);
            this.PbBanner.Name = "PbBanner";
            this.PbBanner.Size = new System.Drawing.Size(509, 220);
            this.PbBanner.TabIndex = 7;
            this.PbBanner.TabStop = false;
            // 
            // PbSculenta
            // 
            this.PbSculenta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PbSculenta.BackgroundImage")));
            this.PbSculenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbSculenta.Location = new System.Drawing.Point(78, 430);
            this.PbSculenta.Name = "PbSculenta";
            this.PbSculenta.Size = new System.Drawing.Size(181, 197);
            this.PbSculenta.TabIndex = 8;
            this.PbSculenta.TabStop = false;
            // 
            // PbCacto
            // 
            this.PbCacto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PbCacto.BackgroundImage")));
            this.PbCacto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbCacto.Location = new System.Drawing.Point(436, 430);
            this.PbCacto.Name = "PbCacto";
            this.PbCacto.Size = new System.Drawing.Size(181, 197);
            this.PbCacto.TabIndex = 9;
            this.PbCacto.TabStop = false;
            // 
            // PbVasos
            // 
            this.PbVasos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PbVasos.BackgroundImage")));
            this.PbVasos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PbVasos.Location = new System.Drawing.Point(799, 430);
            this.PbVasos.Name = "PbVasos";
            this.PbVasos.Size = new System.Drawing.Size(181, 197);
            this.PbVasos.TabIndex = 10;
            this.PbVasos.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pictureBox1.Location = new System.Drawing.Point(31, 393);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(282, 261);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pictureBox2.Location = new System.Drawing.Point(748, 393);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(282, 261);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pictureBox3.Location = new System.Drawing.Point(388, 393);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(282, 261);
            this.pictureBox3.TabIndex = 19;
            this.pictureBox3.TabStop = false;
            // 
            // FrmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(1065, 690);
            this.Controls.Add(this.PbSculenta);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.PbVasos);
            this.Controls.Add(this.PbCacto);
            this.Controls.Add(this.PbBanner);
            this.Controls.Add(this.LblDescricao2);
            this.Controls.Add(this.LblDescricao);
            this.Controls.Add(this.MsHome);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmHome";
            this.Text = "EdenLeaf - Home";
            this.MsHome.ResumeLayout(false);
            this.MsHome.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbBanner)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbSculenta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbCacto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbVasos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip MsHome;
        private System.Windows.Forms.ToolStripMenuItem TsmCompra;
        private System.Windows.Forms.ToolStripMenuItem TsmUsuarios;
        private System.Windows.Forms.ToolStripMenuItem TsmFornecedores;
        private System.Windows.Forms.ToolStripMenuItem TsmProdutos;
        private System.Windows.Forms.Label LblDescricao;
        private System.Windows.Forms.Label LblDescricao2;
        private System.Windows.Forms.PictureBox PbBanner;
        private System.Windows.Forms.PictureBox PbSculenta;
        private System.Windows.Forms.PictureBox PbCacto;
        private System.Windows.Forms.PictureBox PbVasos;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolStripMenuItem TsmInformacoes;
    }
}

