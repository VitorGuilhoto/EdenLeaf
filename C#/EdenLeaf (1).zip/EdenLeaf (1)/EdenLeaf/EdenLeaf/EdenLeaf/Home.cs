﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;
using Npgsql;

namespace EdenLeaf
{
    public partial class FrmHome : Form
    {

        public FrmHome()
        {
            InitializeComponent();

        }

        private void TsmProdutos_Click(object sender, EventArgs e)
        {
            FrmProduto frmProdutos = new FrmProduto();
            frmProdutos.ShowDialog();
        }
        private void TsmFornecedores_Click(object sender, EventArgs e)
        {
            FrmFornecedor frmFornecedores = new FrmFornecedor();
            frmFornecedores.ShowDialog();
        }

        private void TsmInformacoes_Click(object sender, EventArgs e)
        {
            FrmInformacoes frmInformacoes = new FrmInformacoes();
            frmInformacoes.ShowDialog();
        }
    }
}

