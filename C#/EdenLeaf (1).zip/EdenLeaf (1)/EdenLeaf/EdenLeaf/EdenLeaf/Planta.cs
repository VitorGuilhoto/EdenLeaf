﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdenLeaf
{
    internal class Planta
    {
        private int preco;
        private int id_fornecedor;
        private string descricao;
        private DateTime data_adicao;
        private int id;
        private string tipo;

        //TIPO PLANTA ------------------------------------------------------------
        public string getTipo()
        {
            return tipo;
        }

        public void setTipo(string tipo)
        {
            this.tipo = tipo;
        }

        //ID ---------------------------------------------------------------------
        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        //PRECO -------------------------------------------------------------------
        public int getPreco()
        {
            return preco;
        }
        public void setPreco(int preco)
        {
            this.preco = preco;
        }


        //DESCRIÇÃO ----------------------------------------------------------------
        public string getDescricao()
        {
            return descricao;
        }

        public void setDescricao(string descricao)
        {
            this.descricao = descricao;
        }

        // DATA ADIÇÃO ----------------------------------------------------
        public DateTime getData_adicao()
        {
            return data_adicao;
        }

        public void setData_adicao(DateTime data_adicao)
        {
            this.data_adicao = data_adicao;
        }

        //ID ---------------------------------------------------------------
        public int getId_fornecedor()
        {
            return id_fornecedor;
        }

        public void setId_fornecedor(int id_fornecedor)
        {
            this.id_fornecedor = id_fornecedor;
        }

    }
}
