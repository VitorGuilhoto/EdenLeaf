﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONG_Pet_2a
{
    internal sealed class Alien //ninguém herda de alien, pois é selada
    {
    }
}
