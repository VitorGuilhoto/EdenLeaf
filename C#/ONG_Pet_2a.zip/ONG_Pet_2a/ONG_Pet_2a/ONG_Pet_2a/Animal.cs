﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONG_Pet_2a
{
    internal class Animal
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Genero { get; set; }
        public string Tipo { get; set; }
        public string Vacinacao { get; set; }
        public DateTime Data_Nascimento { get; set; }
        public string Status { get; set; }
        public string Disponibilidade_Adocao { get; set; }

        public Animal()
        {

        }
    }
}
