﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONG_Pet_2a
{
    internal class Carro : IVeiculo // :(dois pontos) serve tanto para implements quanto para extends
    {
        public string Nome { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Ano { get; set; }

        public string Info()
        {
            return $"{Nome} - {Modelo} / {Marca} - {Ano}";
        }
    }
}
