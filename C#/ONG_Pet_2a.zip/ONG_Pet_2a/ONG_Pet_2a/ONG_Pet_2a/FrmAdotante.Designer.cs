﻿namespace ONG_Pet_2a
{
    partial class FrmAdotante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblCidade = new System.Windows.Forms.Label();
            this.TxtCidade = new System.Windows.Forms.TextBox();
            this.TxtRG = new System.Windows.Forms.TextBox();
            this.LblRg = new System.Windows.Forms.Label();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnNovo = new System.Windows.Forms.Button();
            this.LblDataNascimento = new System.Windows.Forms.Label();
            this.LblEstado = new System.Windows.Forms.Label();
            this.LblEndereco = new System.Windows.Forms.Label();
            this.LblCPF = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.DtNascimento = new System.Windows.Forms.DateTimePicker();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtEndereco = new System.Windows.Forms.TextBox();
            this.TxtEstado = new System.Windows.Forms.TextBox();
            this.TxtCPF = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.DtgAnimais = new System.Windows.Forms.DataGridView();
            this.TxtTelefone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAnimais)).BeginInit();
            this.SuspendLayout();
            // 
            // LblCidade
            // 
            this.LblCidade.AutoSize = true;
            this.LblCidade.Location = new System.Drawing.Point(259, 100);
            this.LblCidade.Name = "LblCidade";
            this.LblCidade.Size = new System.Drawing.Size(40, 13);
            this.LblCidade.TabIndex = 64;
            this.LblCidade.Text = "Cidade";
            // 
            // TxtCidade
            // 
            this.TxtCidade.Location = new System.Drawing.Point(262, 116);
            this.TxtCidade.Name = "TxtCidade";
            this.TxtCidade.Size = new System.Drawing.Size(159, 20);
            this.TxtCidade.TabIndex = 63;
            // 
            // TxtRG
            // 
            this.TxtRG.Location = new System.Drawing.Point(175, 55);
            this.TxtRG.Name = "TxtRG";
            this.TxtRG.Size = new System.Drawing.Size(170, 20);
            this.TxtRG.TabIndex = 62;
            // 
            // LblRg
            // 
            this.LblRg.AutoSize = true;
            this.LblRg.Location = new System.Drawing.Point(184, 39);
            this.LblRg.Name = "LblRg";
            this.LblRg.Size = new System.Drawing.Size(23, 13);
            this.LblRg.TabIndex = 61;
            this.LblRg.Text = "RG";
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnCancelar.Location = new System.Drawing.Point(385, 173);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(97, 33);
            this.BtnCancelar.TabIndex = 60;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Visible = false;
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.BackColor = System.Drawing.Color.Red;
            this.BtnExcluir.Location = new System.Drawing.Point(262, 173);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(97, 33);
            this.BtnExcluir.TabIndex = 59;
            this.BtnExcluir.Text = "Excluir";
            this.BtnExcluir.UseVisualStyleBackColor = false;
            this.BtnExcluir.Visible = false;
            // 
            // BtnEditar
            // 
            this.BtnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnEditar.Location = new System.Drawing.Point(137, 173);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(97, 33);
            this.BtnEditar.TabIndex = 58;
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.UseVisualStyleBackColor = false;
            this.BtnEditar.Visible = false;
            // 
            // BtnNovo
            // 
            this.BtnNovo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnNovo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnNovo.Location = new System.Drawing.Point(12, 173);
            this.BtnNovo.Name = "BtnNovo";
            this.BtnNovo.Size = new System.Drawing.Size(97, 33);
            this.BtnNovo.TabIndex = 57;
            this.BtnNovo.Text = "Novo Adotante";
            this.BtnNovo.UseVisualStyleBackColor = false;
            // 
            // LblDataNascimento
            // 
            this.LblDataNascimento.AutoSize = true;
            this.LblDataNascimento.Location = new System.Drawing.Point(557, 39);
            this.LblDataNascimento.Name = "LblDataNascimento";
            this.LblDataNascimento.Size = new System.Drawing.Size(102, 13);
            this.LblDataNascimento.TabIndex = 56;
            this.LblDataNascimento.Text = "Data de nascimento";
            // 
            // LblEstado
            // 
            this.LblEstado.AutoSize = true;
            this.LblEstado.Location = new System.Drawing.Point(442, 100);
            this.LblEstado.Name = "LblEstado";
            this.LblEstado.Size = new System.Drawing.Size(40, 13);
            this.LblEstado.TabIndex = 55;
            this.LblEstado.Text = "Estado";
            // 
            // LblEndereco
            // 
            this.LblEndereco.AutoSize = true;
            this.LblEndereco.Location = new System.Drawing.Point(12, 100);
            this.LblEndereco.Name = "LblEndereco";
            this.LblEndereco.Size = new System.Drawing.Size(53, 13);
            this.LblEndereco.TabIndex = 54;
            this.LblEndereco.Text = "Endereço";
            // 
            // LblCPF
            // 
            this.LblCPF.AutoSize = true;
            this.LblCPF.Location = new System.Drawing.Point(363, 39);
            this.LblCPF.Name = "LblCPF";
            this.LblCPF.Size = new System.Drawing.Size(27, 13);
            this.LblCPF.TabIndex = 53;
            this.LblCPF.Text = "CPF";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(12, 39);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(38, 13);
            this.LblNome.TabIndex = 52;
            this.LblNome.Text = "Nome ";
            // 
            // DtNascimento
            // 
            this.DtNascimento.Location = new System.Drawing.Point(560, 55);
            this.DtNascimento.Name = "DtNascimento";
            this.DtNascimento.Size = new System.Drawing.Size(228, 20);
            this.DtNascimento.TabIndex = 51;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(15, 55);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(145, 20);
            this.TxtNome.TabIndex = 50;
            // 
            // TxtEndereco
            // 
            this.TxtEndereco.Location = new System.Drawing.Point(15, 116);
            this.TxtEndereco.Name = "TxtEndereco";
            this.TxtEndereco.Size = new System.Drawing.Size(219, 20);
            this.TxtEndereco.TabIndex = 49;
            // 
            // TxtEstado
            // 
            this.TxtEstado.Location = new System.Drawing.Point(444, 116);
            this.TxtEstado.Name = "TxtEstado";
            this.TxtEstado.Size = new System.Drawing.Size(161, 20);
            this.TxtEstado.TabIndex = 48;
            // 
            // TxtCPF
            // 
            this.TxtCPF.Location = new System.Drawing.Point(366, 55);
            this.TxtCPF.Name = "TxtCPF";
            this.TxtCPF.Size = new System.Drawing.Size(170, 20);
            this.TxtCPF.TabIndex = 47;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::ONG_Pet_2a.Properties.Resources.lupa_png;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(314, 233);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 20);
            this.button1.TabIndex = 46;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(12, 236);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(71, 13);
            this.LblBusca.TabIndex = 45;
            this.LblBusca.Text = "Pesquisar por";
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(89, 233);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(219, 20);
            this.TxtBusca.TabIndex = 44;
            // 
            // DtgAnimais
            // 
            this.DtgAnimais.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgAnimais.Location = new System.Drawing.Point(12, 262);
            this.DtgAnimais.Name = "DtgAnimais";
            this.DtgAnimais.Size = new System.Drawing.Size(776, 150);
            this.DtgAnimais.TabIndex = 43;
            // 
            // TxtTelefone
            // 
            this.TxtTelefone.Location = new System.Drawing.Point(626, 116);
            this.TxtTelefone.Name = "TxtTelefone";
            this.TxtTelefone.Size = new System.Drawing.Size(162, 20);
            this.TxtTelefone.TabIndex = 65;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(623, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 66;
            this.label1.Text = "Telefone";
            // 
            // FrmAdotante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtTelefone);
            this.Controls.Add(this.LblCidade);
            this.Controls.Add(this.TxtCidade);
            this.Controls.Add(this.TxtRG);
            this.Controls.Add(this.LblRg);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnExcluir);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnNovo);
            this.Controls.Add(this.LblDataNascimento);
            this.Controls.Add(this.LblEstado);
            this.Controls.Add(this.LblEndereco);
            this.Controls.Add(this.LblCPF);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.DtNascimento);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtEndereco);
            this.Controls.Add(this.TxtEstado);
            this.Controls.Add(this.TxtCPF);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgAnimais);
            this.Name = "FrmAdotante";
            this.Text = "ONG Pet do CTI - Pessoa adotante";
            ((System.ComponentModel.ISupportInitialize)(this.DtgAnimais)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblCidade;
        private System.Windows.Forms.TextBox TxtCidade;
        private System.Windows.Forms.TextBox TxtRG;
        private System.Windows.Forms.Label LblRg;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnExcluir;
        private System.Windows.Forms.Button BtnEditar;
        private System.Windows.Forms.Button BtnNovo;
        private System.Windows.Forms.Label LblDataNascimento;
        private System.Windows.Forms.Label LblEstado;
        private System.Windows.Forms.Label LblEndereco;
        private System.Windows.Forms.Label LblCPF;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.DateTimePicker DtNascimento;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtEndereco;
        private System.Windows.Forms.TextBox TxtEstado;
        private System.Windows.Forms.TextBox TxtCPF;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label LblBusca;
        private System.Windows.Forms.TextBox TxtBusca;
        private System.Windows.Forms.DataGridView DtgAnimais;
        private System.Windows.Forms.TextBox TxtTelefone;
        private System.Windows.Forms.Label label1;
    }
}