﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ONG_Pet_2a
{
    public partial class FrmAjuda : Form
    {
        public FrmAjuda()
        {
            InitializeComponent();
        }

        private void FrmAjuda_Load(object sender, EventArgs e)
        {
            LblAjuda.Text = "ONG Pet do CTI - INI2A\n"+
                "Projeto de Aplicação em .NET\n\n\n"+
                "Suporte: CTI - 0800 755 888\n"+
                "Contato comercial: (14) 3698-2574";
        }
    }
}
