﻿namespace ONG_Pet_2a
{
    partial class FrmAnimal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnNovo = new System.Windows.Forms.Button();
            this.LblDataNascimento = new System.Windows.Forms.Label();
            this.LblDisponibilidade = new System.Windows.Forms.Label();
            this.LblVacinacao = new System.Windows.Forms.Label();
            this.LblGenero = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.DtNascimento = new System.Windows.Forms.DateTimePicker();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtVacinacao = new System.Windows.Forms.TextBox();
            this.TxtDisponibilidade = new System.Windows.Forms.TextBox();
            this.TxtGenero = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.LblBusca = new System.Windows.Forms.Label();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.DtgAnimais = new System.Windows.Forms.DataGridView();
            this.LblTipo = new System.Windows.Forms.Label();
            this.TxtTipo = new System.Windows.Forms.TextBox();
            this.TxtStatus = new System.Windows.Forms.TextBox();
            this.LblStatus = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAnimais)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnCancelar.Location = new System.Drawing.Point(385, 173);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(97, 33);
            this.BtnCancelar.TabIndex = 38;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Visible = false;
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.BackColor = System.Drawing.Color.Red;
            this.BtnExcluir.Location = new System.Drawing.Point(262, 173);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(97, 33);
            this.BtnExcluir.TabIndex = 37;
            this.BtnExcluir.Text = "Excluir";
            this.BtnExcluir.UseVisualStyleBackColor = false;
            this.BtnExcluir.Visible = false;
            // 
            // BtnEditar
            // 
            this.BtnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnEditar.Location = new System.Drawing.Point(137, 173);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(97, 33);
            this.BtnEditar.TabIndex = 36;
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.UseVisualStyleBackColor = false;
            this.BtnEditar.Visible = false;
            // 
            // BtnNovo
            // 
            this.BtnNovo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnNovo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnNovo.Location = new System.Drawing.Point(12, 173);
            this.BtnNovo.Name = "BtnNovo";
            this.BtnNovo.Size = new System.Drawing.Size(97, 33);
            this.BtnNovo.TabIndex = 35;
            this.BtnNovo.Text = "Novo Animal";
            this.BtnNovo.UseVisualStyleBackColor = false;
            // 
            // LblDataNascimento
            // 
            this.LblDataNascimento.AutoSize = true;
            this.LblDataNascimento.Location = new System.Drawing.Point(12, 100);
            this.LblDataNascimento.Name = "LblDataNascimento";
            this.LblDataNascimento.Size = new System.Drawing.Size(102, 13);
            this.LblDataNascimento.TabIndex = 34;
            this.LblDataNascimento.Text = "Data de nascimento";
            // 
            // LblDisponibilidade
            // 
            this.LblDisponibilidade.AutoSize = true;
            this.LblDisponibilidade.Location = new System.Drawing.Point(392, 100);
            this.LblDisponibilidade.Name = "LblDisponibilidade";
            this.LblDisponibilidade.Size = new System.Drawing.Size(121, 13);
            this.LblDisponibilidade.TabIndex = 33;
            this.LblDisponibilidade.Text = "Disponível para adoção";
            // 
            // LblVacinacao
            // 
            this.LblVacinacao.AutoSize = true;
            this.LblVacinacao.Location = new System.Drawing.Point(528, 39);
            this.LblVacinacao.Name = "LblVacinacao";
            this.LblVacinacao.Size = new System.Drawing.Size(58, 13);
            this.LblVacinacao.TabIndex = 32;
            this.LblVacinacao.Text = "Vacinação";
            // 
            // LblGenero
            // 
            this.LblGenero.AutoSize = true;
            this.LblGenero.Location = new System.Drawing.Point(358, 39);
            this.LblGenero.Name = "LblGenero";
            this.LblGenero.Size = new System.Drawing.Size(42, 13);
            this.LblGenero.TabIndex = 31;
            this.LblGenero.Text = "Gênero";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(12, 39);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(83, 13);
            this.LblNome.TabIndex = 30;
            this.LblNome.Text = "Nome do animal";
            // 
            // DtNascimento
            // 
            this.DtNascimento.Location = new System.Drawing.Point(15, 116);
            this.DtNascimento.Name = "DtNascimento";
            this.DtNascimento.Size = new System.Drawing.Size(200, 20);
            this.DtNascimento.TabIndex = 29;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(15, 55);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(145, 20);
            this.TxtNome.TabIndex = 28;
            // 
            // TxtVacinacao
            // 
            this.TxtVacinacao.Location = new System.Drawing.Point(531, 55);
            this.TxtVacinacao.Name = "TxtVacinacao";
            this.TxtVacinacao.Size = new System.Drawing.Size(140, 20);
            this.TxtVacinacao.TabIndex = 27;
            // 
            // TxtDisponibilidade
            // 
            this.TxtDisponibilidade.Location = new System.Drawing.Point(395, 116);
            this.TxtDisponibilidade.Name = "TxtDisponibilidade";
            this.TxtDisponibilidade.Size = new System.Drawing.Size(148, 20);
            this.TxtDisponibilidade.TabIndex = 26;
            // 
            // TxtGenero
            // 
            this.TxtGenero.Location = new System.Drawing.Point(361, 55);
            this.TxtGenero.Name = "TxtGenero";
            this.TxtGenero.Size = new System.Drawing.Size(121, 20);
            this.TxtGenero.TabIndex = 25;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::ONG_Pet_2a.Properties.Resources.lupa_png;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(314, 233);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 20);
            this.button1.TabIndex = 24;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(12, 236);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(71, 13);
            this.LblBusca.TabIndex = 23;
            this.LblBusca.Text = "Pesquisar por";
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(89, 233);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(219, 20);
            this.TxtBusca.TabIndex = 22;
            // 
            // DtgAnimais
            // 
            this.DtgAnimais.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgAnimais.Location = new System.Drawing.Point(12, 262);
            this.DtgAnimais.Name = "DtgAnimais";
            this.DtgAnimais.Size = new System.Drawing.Size(776, 150);
            this.DtgAnimais.TabIndex = 21;
         
            // 
            // LblTipo
            // 
            this.LblTipo.AutoSize = true;
            this.LblTipo.Location = new System.Drawing.Point(187, 39);
            this.LblTipo.Name = "LblTipo";
            this.LblTipo.Size = new System.Drawing.Size(28, 13);
            this.LblTipo.TabIndex = 39;
            this.LblTipo.Text = "Tipo";
            // 
            // TxtTipo
            // 
            this.TxtTipo.Location = new System.Drawing.Point(187, 55);
            this.TxtTipo.Name = "TxtTipo";
            this.TxtTipo.Size = new System.Drawing.Size(121, 20);
            this.TxtTipo.TabIndex = 40;
            this.TxtTipo.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TxtStatus
            // 
            this.TxtStatus.Location = new System.Drawing.Point(238, 116);
            this.TxtStatus.Name = "TxtStatus";
            this.TxtStatus.Size = new System.Drawing.Size(121, 20);
            this.TxtStatus.TabIndex = 41;
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = true;
            this.LblStatus.Location = new System.Drawing.Point(237, 100);
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.Size = new System.Drawing.Size(98, 13);
            this.LblStatus.TabIndex = 42;
            this.LblStatus.Text = "Situação do Animal";
            // 
            // FrmAnimal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblStatus);
            this.Controls.Add(this.TxtStatus);
            this.Controls.Add(this.TxtTipo);
            this.Controls.Add(this.LblTipo);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnExcluir);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnNovo);
            this.Controls.Add(this.LblDataNascimento);
            this.Controls.Add(this.LblDisponibilidade);
            this.Controls.Add(this.LblVacinacao);
            this.Controls.Add(this.LblGenero);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.DtNascimento);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtVacinacao);
            this.Controls.Add(this.TxtDisponibilidade);
            this.Controls.Add(this.TxtGenero);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgAnimais);
            this.Name = "FrmAnimal";
            this.Text = "ONG Pet do CTI - Animais";
            ((System.ComponentModel.ISupportInitialize)(this.DtgAnimais)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnExcluir;
        private System.Windows.Forms.Button BtnEditar;
        private System.Windows.Forms.Button BtnNovo;
        private System.Windows.Forms.Label LblDataNascimento;
        private System.Windows.Forms.Label LblDisponibilidade;
        private System.Windows.Forms.Label LblVacinacao;
        private System.Windows.Forms.Label LblGenero;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.DateTimePicker DtNascimento;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtVacinacao;
        private System.Windows.Forms.TextBox TxtDisponibilidade;
        private System.Windows.Forms.TextBox TxtGenero;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label LblBusca;
        private System.Windows.Forms.TextBox TxtBusca;
        private System.Windows.Forms.DataGridView DtgAnimais;
        private System.Windows.Forms.Label LblTipo;
        private System.Windows.Forms.TextBox TxtTipo;
        private System.Windows.Forms.TextBox TxtStatus;
        private System.Windows.Forms.Label LblStatus;
    }
}