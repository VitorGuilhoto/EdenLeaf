﻿namespace ONG_Pet_2a
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenuPrincipal = new System.Windows.Forms.MenuStrip();
            this.TsmCadastros = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmiAnimais = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmiAdotantes = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmAjuda = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmiAjuda = new System.Windows.Forms.ToolStripMenuItem();
            this.TsRodape = new System.Windows.Forms.StatusStrip();
            this.DtgAdocao = new System.Windows.Forms.DataGridView();
            this.TxtBusca = new System.Windows.Forms.TextBox();
            this.LblBusca = new System.Windows.Forms.Label();
            this.BtnBusca = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.TxtInformacoes = new System.Windows.Forms.TextBox();
            this.TxtStatus = new System.Windows.Forms.TextBox();
            this.DtAdocao = new System.Windows.Forms.DateTimePicker();
            this.LblAnimal = new System.Windows.Forms.Label();
            this.LblAdotante = new System.Windows.Forms.Label();
            this.LblStatus = new System.Windows.Forms.Label();
            this.LblInformacoes = new System.Windows.Forms.Label();
            this.LblDataAdocao = new System.Windows.Forms.Label();
            this.BtnNovo = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.CblAnimal = new System.Windows.Forms.ComboBox();
            this.CblAdotante = new System.Windows.Forms.ComboBox();
            this.TslPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.MenuPrincipal.SuspendLayout();
            this.TsRodape.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAdocao)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuPrincipal
            // 
            this.MenuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmCadastros,
            this.TsmAjuda});
            this.MenuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.MenuPrincipal.Name = "MenuPrincipal";
            this.MenuPrincipal.Size = new System.Drawing.Size(800, 24);
            this.MenuPrincipal.TabIndex = 0;
            this.MenuPrincipal.Text = "menuStrip1";
            // 
            // TsmCadastros
            // 
            this.TsmCadastros.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmiAnimais,
            this.TsmiAdotantes});
            this.TsmCadastros.Name = "TsmCadastros";
            this.TsmCadastros.Size = new System.Drawing.Size(71, 20);
            this.TsmCadastros.Text = "Cadastros";
            // 
            // TsmiAnimais
            // 
            this.TsmiAnimais.Name = "TsmiAnimais";
            this.TsmiAnimais.Size = new System.Drawing.Size(128, 22);
            this.TsmiAnimais.Text = "Animais";
            this.TsmiAnimais.Click += new System.EventHandler(this.TsmiAnimais_Click);
            // 
            // TsmiAdotantes
            // 
            this.TsmiAdotantes.Name = "TsmiAdotantes";
            this.TsmiAdotantes.Size = new System.Drawing.Size(128, 22);
            this.TsmiAdotantes.Text = "Adotantes";
            // 
            // TsmAjuda
            // 
            this.TsmAjuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmiAjuda});
            this.TsmAjuda.Name = "TsmAjuda";
            this.TsmAjuda.Size = new System.Drawing.Size(50, 20);
            this.TsmAjuda.Text = "Ajuda";
            // 
            // TsmiAjuda
            // 
            this.TsmiAjuda.Name = "TsmiAjuda";
            this.TsmiAjuda.Size = new System.Drawing.Size(105, 22);
            this.TsmiAjuda.Text = "Ajuda";
            this.TsmiAjuda.Click += new System.EventHandler(this.TsmiAjuda_Click);
            // 
            // TsRodape
            // 
            this.TsRodape.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslPrincipal});
            this.TsRodape.Location = new System.Drawing.Point(0, 409);
            this.TsRodape.Name = "TsRodape";
            this.TsRodape.Size = new System.Drawing.Size(800, 22);
            this.TsRodape.TabIndex = 1;
            this.TsRodape.Text = "statusStrip1";
            // 
            // DtgAdocao
            // 
            this.DtgAdocao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgAdocao.Location = new System.Drawing.Point(12, 261);
            this.DtgAdocao.MultiSelect = false;
            this.DtgAdocao.Name = "DtgAdocao";
            this.DtgAdocao.Size = new System.Drawing.Size(776, 150);
            this.DtgAdocao.TabIndex = 2;
            this.DtgAdocao.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DtgAdocao_RowHeaderMouseClick);
            // 
            // TxtBusca
            // 
            this.TxtBusca.Location = new System.Drawing.Point(89, 232);
            this.TxtBusca.Name = "TxtBusca";
            this.TxtBusca.Size = new System.Drawing.Size(219, 20);
            this.TxtBusca.TabIndex = 3;
            // 
            // LblBusca
            // 
            this.LblBusca.AutoSize = true;
            this.LblBusca.Location = new System.Drawing.Point(12, 235);
            this.LblBusca.Name = "LblBusca";
            this.LblBusca.Size = new System.Drawing.Size(71, 13);
            this.LblBusca.TabIndex = 4;
            this.LblBusca.Text = "Pesquisar por";
            // 
            // BtnBusca
            // 
            this.BtnBusca.BackgroundImage = global::ONG_Pet_2a.Properties.Resources.lupa_png;
            this.BtnBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnBusca.Location = new System.Drawing.Point(314, 232);
            this.BtnBusca.Name = "BtnBusca";
            this.BtnBusca.Size = new System.Drawing.Size(21, 20);
            this.BtnBusca.TabIndex = 5;
            this.BtnBusca.UseVisualStyleBackColor = true;
            this.BtnBusca.Click += new System.EventHandler(this.BtnBusca_Click);
            // 
            // TxtInformacoes
            // 
            this.TxtInformacoes.Location = new System.Drawing.Point(249, 115);
            this.TxtInformacoes.Name = "TxtInformacoes";
            this.TxtInformacoes.Size = new System.Drawing.Size(539, 20);
            this.TxtInformacoes.TabIndex = 8;
            // 
            // TxtStatus
            // 
            this.TxtStatus.Location = new System.Drawing.Point(541, 54);
            this.TxtStatus.Name = "TxtStatus";
            this.TxtStatus.Size = new System.Drawing.Size(247, 20);
            this.TxtStatus.TabIndex = 9;
            // 
            // DtAdocao
            // 
            this.DtAdocao.Location = new System.Drawing.Point(15, 115);
            this.DtAdocao.Name = "DtAdocao";
            this.DtAdocao.Size = new System.Drawing.Size(200, 20);
            this.DtAdocao.TabIndex = 11;
            // 
            // LblAnimal
            // 
            this.LblAnimal.AutoSize = true;
            this.LblAnimal.Location = new System.Drawing.Point(12, 38);
            this.LblAnimal.Name = "LblAnimal";
            this.LblAnimal.Size = new System.Drawing.Size(83, 13);
            this.LblAnimal.TabIndex = 12;
            this.LblAnimal.Text = "Nome do animal";
            // 
            // LblAdotante
            // 
            this.LblAdotante.AutoSize = true;
            this.LblAdotante.Location = new System.Drawing.Point(187, 38);
            this.LblAdotante.Name = "LblAdotante";
            this.LblAdotante.Size = new System.Drawing.Size(87, 13);
            this.LblAdotante.TabIndex = 13;
            this.LblAdotante.Text = "Pessoa adotante";
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = true;
            this.LblStatus.Location = new System.Drawing.Point(538, 38);
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.Size = new System.Drawing.Size(49, 13);
            this.LblStatus.TabIndex = 14;
            this.LblStatus.Text = "Situação";
            // 
            // LblInformacoes
            // 
            this.LblInformacoes.AutoSize = true;
            this.LblInformacoes.Location = new System.Drawing.Point(246, 99);
            this.LblInformacoes.Name = "LblInformacoes";
            this.LblInformacoes.Size = new System.Drawing.Size(65, 13);
            this.LblInformacoes.TabIndex = 15;
            this.LblInformacoes.Text = "Informações";
            // 
            // LblDataAdocao
            // 
            this.LblDataAdocao.AutoSize = true;
            this.LblDataAdocao.Location = new System.Drawing.Point(12, 99);
            this.LblDataAdocao.Name = "LblDataAdocao";
            this.LblDataAdocao.Size = new System.Drawing.Size(84, 13);
            this.LblDataAdocao.TabIndex = 16;
            this.LblDataAdocao.Text = "Data da adoção";
            // 
            // BtnNovo
            // 
            this.BtnNovo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnNovo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnNovo.Location = new System.Drawing.Point(12, 172);
            this.BtnNovo.Name = "BtnNovo";
            this.BtnNovo.Size = new System.Drawing.Size(97, 33);
            this.BtnNovo.TabIndex = 17;
            this.BtnNovo.Text = "Nova Adoção";
            this.BtnNovo.UseVisualStyleBackColor = false;
            // 
            // BtnEditar
            // 
            this.BtnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnEditar.Location = new System.Drawing.Point(137, 172);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(97, 33);
            this.BtnEditar.TabIndex = 18;
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.UseVisualStyleBackColor = false;
            this.BtnEditar.Visible = false;
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.BackColor = System.Drawing.Color.Red;
            this.BtnExcluir.Location = new System.Drawing.Point(262, 172);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(97, 33);
            this.BtnExcluir.TabIndex = 19;
            this.BtnExcluir.Text = "Excluir";
            this.BtnExcluir.UseVisualStyleBackColor = false;
            this.BtnExcluir.Visible = false;
            this.BtnExcluir.Click += new System.EventHandler(this.BtnExcluir_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BtnCancelar.Location = new System.Drawing.Point(385, 172);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(97, 33);
            this.BtnCancelar.TabIndex = 20;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Visible = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // CblAnimal
            // 
            this.CblAnimal.FormattingEnabled = true;
            this.CblAnimal.Location = new System.Drawing.Point(15, 53);
            this.CblAnimal.Name = "CblAnimal";
            this.CblAnimal.Size = new System.Drawing.Size(121, 21);
            this.CblAnimal.TabIndex = 21;
            this.CblAnimal.SelectedIndexChanged += new System.EventHandler(this.CblAnimal_SelectedIndexChanged);
            // 
            // CblAdotante
            // 
            this.CblAdotante.FormattingEnabled = true;
            this.CblAdotante.Location = new System.Drawing.Point(187, 53);
            this.CblAdotante.Name = "CblAdotante";
            this.CblAdotante.Size = new System.Drawing.Size(272, 21);
            this.CblAdotante.TabIndex = 22;
            this.CblAdotante.SelectedIndexChanged += new System.EventHandler(this.CblAdotante_SelectedIndexChanged);
            // 
            // TslPrincipal
            // 
            this.TslPrincipal.Name = "TslPrincipal";
            this.TslPrincipal.Size = new System.Drawing.Size(0, 17);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 431);
            this.Controls.Add(this.CblAdotante);
            this.Controls.Add(this.CblAnimal);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnExcluir);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnNovo);
            this.Controls.Add(this.LblDataAdocao);
            this.Controls.Add(this.LblInformacoes);
            this.Controls.Add(this.LblStatus);
            this.Controls.Add(this.LblAdotante);
            this.Controls.Add(this.LblAnimal);
            this.Controls.Add(this.DtAdocao);
            this.Controls.Add(this.TxtStatus);
            this.Controls.Add(this.TxtInformacoes);
            this.Controls.Add(this.BtnBusca);
            this.Controls.Add(this.LblBusca);
            this.Controls.Add(this.TxtBusca);
            this.Controls.Add(this.DtgAdocao);
            this.Controls.Add(this.TsRodape);
            this.Controls.Add(this.MenuPrincipal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.MenuPrincipal;
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.Text = "ONG Pet do CTI";
            this.MenuPrincipal.ResumeLayout(false);
            this.MenuPrincipal.PerformLayout();
            this.TsRodape.ResumeLayout(false);
            this.TsRodape.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DtgAdocao)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MenuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem TsmCadastros;
        private System.Windows.Forms.ToolStripMenuItem TsmiAnimais;
        private System.Windows.Forms.ToolStripMenuItem TsmiAdotantes;
        private System.Windows.Forms.ToolStripMenuItem TsmAjuda;
        private System.Windows.Forms.ToolStripMenuItem TsmiAjuda;
        private System.Windows.Forms.StatusStrip TsRodape;
        private System.Windows.Forms.DataGridView DtgAdocao;
        private System.Windows.Forms.TextBox TxtBusca;
        private System.Windows.Forms.Label LblBusca;
        private System.Windows.Forms.Button BtnBusca;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Windows.Forms.TextBox TxtInformacoes;
        private System.Windows.Forms.TextBox TxtStatus;
        private System.Windows.Forms.DateTimePicker DtAdocao;
        private System.Windows.Forms.Label LblAnimal;
        private System.Windows.Forms.Label LblAdotante;
        private System.Windows.Forms.Label LblStatus;
        private System.Windows.Forms.Label LblInformacoes;
        private System.Windows.Forms.Label LblDataAdocao;
        private System.Windows.Forms.Button BtnNovo;
        private System.Windows.Forms.Button BtnEditar;
        private System.Windows.Forms.Button BtnExcluir;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.ComboBox CblAnimal;
        private System.Windows.Forms.ComboBox CblAdotante;
        private System.Windows.Forms.ToolStripStatusLabel TslPrincipal;
    }
}

