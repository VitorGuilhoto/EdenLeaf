﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;
using Npgsql;

namespace ONG_Pet_2a
{
    public partial class FrmPrincipal : Form
    {
        NpgsqlConnection conexao;

        int IdAnimal;
        int IdAdotante;
        int IdAdocao;

        public FrmPrincipal()
        {
            InitializeComponent();

            conexao = new NpgsqlConnection(connectionString:
                "Server=localhost; " +
                "Port=5432; " +
                "User ID=postgres; " +
                "Password=postgres; " +
                "Database=projeto_2a; " +
                "Pooling=true;"
            );

            CarregarDados(null);
            CarregarListaDados();
        }

        private void TsmiAnimais_Click(object sender, EventArgs e)
        {
            FrmAnimal frmAnimal = new FrmAnimal();
            frmAnimal.ShowDialog();
        }

        private void TsmiAdotante_Click(object sender, EventArgs e)
        {
            FrmAdotante frmAdotante = new FrmAdotante();
            frmAdotante.ShowDialog();
        }

        private void TsmiAjuda_Click(object sender, EventArgs e)
        {
            FrmAjuda frmAjuda = new FrmAjuda();
            frmAjuda.ShowDialog();
        }

        private void CarregarDados(string comando)
        {
            string query = comando != null
                           ? comando
                           : "SELECT ac.id AS Id_Adocao, an.id AS Id_Animal," +
                           "an.nome AS animal, an.tipo," +
                           "ad.id AS Id_Adotante," +
                           "ad.nome AS adotante, ac.data_adocao," +
                           "ac.status, ac.informacoes " +
                           "FROM adocao AS ac " +
                           "INNER JOIN animal AS an ON ac.animal = an.id " +
                           "INNER JOIN adotante AS ad ON ac.adotante = ad.id;";

            try
            {
                conexao.Open();

                using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(query, conexao))
                {
                    using (DataTable dt = new DataTable())
                    {
                        da.Fill(dt);
                        DtgAdocao.DataSource = dt;
                    }
                }

                conexao.Close();
                TslPrincipal.Text = "Pronto!";
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
                TslPrincipal.Text = "ERRO: " + ex.Message;
            }


        }



        private void BtnBusca_Click(object sender, EventArgs e)
        {
            string query = "SELECT an.nome AS animal, an.tipo, " +
                "ad.nome AS adotante," +
                "ac.data_adocao," +
                "ac.status," +
                "ac.informacoes " +
                "FROM adocao AS ac " +
                "INNER JOIN animal AS an ON ac.animal = an.id " +
                "INNER JOIN adotante AS ad ON ac.adotante = ad.id " +
                $"WHERE ad.nome LIKE '%{TxtBusca.Text}%' or an.nome LIKE '%{TxtBusca.Text}%';";
            CarregarDados(query);
        }

        private void BtnNovo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(CblAnimal.Text) &&
                !string.IsNullOrEmpty(CblAdotante.Text) &&
                !string.IsNullOrEmpty(TxtStatus.Text) &&
                !string.IsNullOrEmpty(TxtInformacoes.Text) &&
                !string.IsNullOrEmpty(CblAnimal.Text) &&
                !string.IsNullOrEmpty(CblAdotante.Text))
            {


                try
                {
                    var day = DtAdocao.Value.Day;
                    var month = DtAdocao.Value.Month;
                    var year = DtAdocao.Value.Year;
                    string dataAdocao = year +"/"+ month + "/"+ day;

                    if (this.IdAnimal != 0 && this.IdAdotante != 0)
                    {

                        var query = "INSERT INTO adocao (animal, adotante, " +
                            "data_adocao, status, informacoes) VALUES " +
                            $"({this.IdAnimal},{this.IdAdotante},'{dataAdocao}'," +
                            $"'{TxtStatus.Text},'{TxtInformacoes.Text}')";

                        var queryDisponibilidade = "UPDATE animal SET disponibilidade_adocao = false" +
                                                   $"WHERE id = {this.IdAnimal};";

                        conexao.Query(sql: query); //Executa a inserção de dados
                        conexao.Query(sql: queryDisponibilidade); //Executa a atualização do animal
                                                                  //para nao disponivel para novas adoções
                        MessageBox.Show("Nova doção feita com sucesso!"); 
                        LimpaCampos();
                        CarregarDados(null);
                    } 
                    else
                    {
                        MessageBox.Show("Animal e/ou pessoa adotante não encontrados!");
                        TslPrincipal.Text = "Animal e/ou pessoa adotante não encontrados!";
                    }
                
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                    TslPrincipal.Text = "Erro: " + ex.Message;
                }
            }
            else
            {
                MessageBox.Show("Campos obrigatórios não preenchidos!");
                TslPrincipal.Text = "Campos obrigatórios não preenchidos!";

                if (string.IsNullOrEmpty(CblAnimal.Text))
                    LblAnimal.Font = new Font(this.Font, FontStyle.Bold);
                if (string.IsNullOrEmpty(CblAdotante.Text))
                    LblAdotante.Font = new Font(this.Font, FontStyle.Bold);
                if (string.IsNullOrEmpty(TxtStatus.Text))
                    LblStatus.Font = new Font(this.Font, FontStyle.Bold);
                if (string.IsNullOrEmpty(TxtInformacoes.Text))
                    LblInformacoes.Font = new Font(this.Font, FontStyle.Bold);
            }
        }

            private void CarregarListaDados()
            {
                try
                {
                    var queryAnimal = "SELECT * FROM animal WHERE disponibilidade_adocao = true;";
                    var queryAdotante = "SELECT * FROM adotante;";

                    var listaAnimal = conexao.Query<Animal>(sql: queryAnimal);
                    var listaAdotante = conexao.Query<Adotante>(sql: queryAdotante);

                    foreach (var animal in listaAnimal) CblAnimal.Items.Add(animal.Nome);
                    foreach (var pessoa in listaAdotante) CblAdotante.Items.Add(pessoa.Nome);
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                    TslPrincipal.Text = "Erro: " + ex.Message;
                }
            }

        private void LimpaCampos()
        {
            CblAdotante.ResetText();
            CblAnimal.ResetText();

            TxtInformacoes.Clear();
            TxtStatus.Clear();
            DtAdocao.ResetText();

        }

        private void Reset()
        {
            BtnEditar.Visible = false;
            BtnExcluir.Visible = false;
            BtnCancelar.Visible = false;
            BtnNovo.Visible = true;

            CblAdotante.Enabled = true;
            CblAnimal.Enabled = true;
        }

        private void CblAnimal_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var query = $"SELECT id FROM animal WHERE nome = '{CblAnimal.Text}';";
                dynamic resultado = conexao.Query<Animal>(sql: query);

                this.IdAnimal = resultado[0].Id; //Atribui o animal selecionado ao ID

            } catch (NpgsqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
                TslPrincipal.Text = "Erro: " + ex.Message;
            }
        }

        private void CblAdotante_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var query = $"SELECT id FROM adotante WHERE nome = '{CblAdotante.Text}';";
                dynamic resultado = conexao.Query<Adotante>(sql: query);

                this.IdAdotante = resultado[0].Id; //Atribui o adotante selecionado ao ID

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
                TslPrincipal.Text = "Erro: " + ex.Message;
            }
        }

        private void DtgAdocao_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            this.IdAdocao = (int)DtgAdocao.SelectedRows[0].Cells[0].Value;
            this.IdAdotante = (int)DtgAdocao.SelectedRows[0].Cells[4].Value;
            this.IdAnimal = (int)DtgAdocao.SelectedRows[0].Cells[1].Value;

            var nomeAnimal = DtgAdocao.SelectedRows[0].Cells[2].Value;
            var nomeAdotante = DtgAdocao.SelectedRows[0].Cells[5].Value;
            var statusAdocao = DtgAdocao.SelectedRows[0].Cells[7].Value;
            var infoAdocao = DtgAdocao.SelectedRows[0].Cells[8].Value;
            var dataAdocao = DtgAdocao.SelectedRows[0].Cells[6].Value;

            var newDate = dataAdocao.ToString().Split('/');
            int d = int.Parse(newDate[0]);
            int m = int.Parse(newDate[1]);
            int y = int.Parse(newDate[2].Split(' ')[0]);
            DtAdocao.Value = new DateTime(y,m,d);

            CblAnimal.Text = nomeAnimal.ToString();
            CblAdotante.Text = nomeAdotante.ToString();
            TxtStatus.Text = statusAdocao.ToString();
            TxtInformacoes.Text = infoAdocao.ToString();

            BtnEditar.Visible = true;
            BtnExcluir.Visible = true;
            BtnCancelar.Visible = true;
            BtnNovo.Visible = false;

            CblAdotante.Enabled = false;
            CblAnimal.Enabled = false;


        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampos();
            Reset();
            CarregarListaDados();
            CarregarDados(null);
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            try
            {

                var day = DtAdocao.Value.Day;
                var month = DtAdocao.Value.Month;
                var year = DtAdocao.Value.Year;
                string dataAdocao = year + "/" + month + "/" + day;

                var update = $"UPDATE adocao SET status ='{TxtStatus.Text}'," +
                    $"data_adocao='{dataAdocao}'," +
                    $"informacoes='{TxtInformacoes.Text}'" +
                    $"WHERE id={IdAdocao};";

                conexao.Query(sql: update);

                MessageBox.Show("Adoção atualizada com sucesso!!!");
                LimpaCampos();
                Reset();
                CarregarListaDados();
                CarregarDados(null);

            } catch (NpgsqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
                TslPrincipal.Text = "Erro: " + ex.Message;
            }
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Deseja excluir esta adoção?",
                                                  "Atenção!",
                                                  MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                try
                {
        
                    var delete = $"DELETE FROM adocao " +
                        $"WHERE id={IdAdocao};";

                    conexao.Query(sql: delete);

                    MessageBox.Show("Adoção excluida com sucesso!!!");
                    LimpaCampos();
                    Reset();
                    CarregarListaDados();
                    CarregarDados(null);

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                    TslPrincipal.Text = "Erro: " + ex.Message;
                }
            }
            else
            {
                LimpaCampos();
                Reset();
                CarregarListaDados();
                CarregarDados(null);
            }
        }
    }
}
