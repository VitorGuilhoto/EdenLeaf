﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONG_Pet_2a
{
    internal interface IVeiculo
    {
        //clásulas, itens obrigatórios
        string Nome { get; set; }
        string Marca { get; set; }
        string Modelo { get; set; }
        int Ano { get; set; }

        string Info();
    }
}
