﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ONG_Pet_2a
{
    internal partial class Pessoa
    {
        public string Nome { get; set; }
        public int Idade { get; set; }
        public string Email { get; set; }

        public Pessoa() { }

        public virtual void Andar()
        {
            MessageBox.Show("Pessoa andando...");
        }
    }
}
