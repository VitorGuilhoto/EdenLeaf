﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONG_Pet_2a
{
    internal abstract class Veiculo
    {
        string Nome { get; set; }
        string Marca { get; set; }
        string Modelo { get; set; }
        int Ano { get; set; }

        public abstract string Info();
    }
}
